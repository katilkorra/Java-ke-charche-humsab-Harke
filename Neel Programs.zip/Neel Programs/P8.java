interface Animal {
    int age = 5;
    void eat();
    void sleep();
}

class Cat implements Animal{
    @Override
    public void eat()
    {
        System.out.println("Cat Eats");
    }
    @Override
    public void sleep()
    {
        System.out.println("Cat is sleeping");
    }
}
class Dog implements Animal{
    @Override
    public void eat()
    {
        System.out.println("Dog eats");
    }
    @Override
    public void sleep()
    {
        System.out.println("Dog is sleeping");
    }
}

public class P8{
    public static void main(String args[])
    {
        Dog dog = new Dog();
        Cat cat = new Cat();
        dog.eat();
        cat.sleep();

        System.out.println(Dog.age);
        System.out.println(Animal.age);
    }
}
 