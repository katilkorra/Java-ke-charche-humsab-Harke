import java.util.Scanner;

public class P10 {
    public static void main(String args[])
    {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the Integer number :");
        int A = input.nextInt();
        input.nextLine();
        System.out.println("Enter the string :");
        String B = input.nextLine();
        System.out.println("Enter float value: ");
        float C = input.nextFloat();
        System.out.println("Enter the Double value : ");
        double D = input.nextDouble();
        System.out.println("Enter the Boolean:");
        boolean E = input.nextBoolean();

        System.out.printf("The values are : " + A + " " + B + " " + C + " " + D + " " + E +" " );
        input.close();
    }
    
}
