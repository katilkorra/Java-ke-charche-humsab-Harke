// import java.util.Arrays;
public class P4 {
    public static void main(String args[])
    {
        int arr[] = new int[args.length];
        int sum = 0 ;

        if(args.length == 0)
        {
            System.out.println("Enter some elements");
        }

        for(int i= 0 ; i<args.length ; i++)
        {
            arr[i] = Integer.parseInt(args[i]);
            sum = sum +=arr[i] ; 
        }

        System.out.print(sum);

    }
}
