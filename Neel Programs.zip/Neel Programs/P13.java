import java.io.*;
public class P13 {
    public static void main(String[] args) {
        String sourceFile = "source.txt";
        String destinationFile = "destination.txt"; 

        try (FileReader fileReader = new FileReader(sourceFile);
             FileOutputStream fileOutputStream = new FileOutputStream(destinationFile)) {

            int character;
            // Read from the source file using character stream
            while ((character = fileReader.read()) != -1) {
                // Write to the destination file using byte stream
                fileOutputStream.write(character);
            }

            System.out.println("File copied successfully!");

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}

