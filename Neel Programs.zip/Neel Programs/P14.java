import java.io.*;
public class P14 {

    public static void main(String[] args) {
        String sourceFile = "source1.txt"; 
        String destinationFile = "destination1.txt"; 

        int lineCount = 0;
        int wordCount = 0;

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(sourceFile));
             FileWriter fileWriter = new FileWriter(destinationFile)) {

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                fileWriter.write(line + System.lineSeparator());
                lineCount++;

                String[] words = line.trim().split("\\s+");
                wordCount += words.length;
            }

            System.out.println("File copied successfully!");
            System.out.println("Total Lines: " + lineCount);
            System.out.println("Total Words: " + wordCount);

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}