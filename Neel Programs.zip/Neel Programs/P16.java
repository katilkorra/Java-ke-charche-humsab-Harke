import java.util.*;
public class P16 {
    public static void main(String[] args) {

        List<Integer> numbers = new ArrayList<>();
        Collections.addAll(numbers, 5, 7, 15, 45, 50, 32, 81, 95, 3, 14);

        // Remove all even numbers from the list
        numbers.removeIf(n -> n % 2 == 0);
        System.out.println("List after removing even numbers: " + numbers);

        // Sort in ascending order
        Collections.sort(numbers);
        System.out.println("Sorted list: " + numbers);

        // Find the maximum and minimum values from the list
        if (!numbers.isEmpty()) {
            int max = Collections.max(numbers);
            int min = Collections.min(numbers);
            System.out.println("Maximum value: " + max);
            System.out.println("Minimum value: " + min);
        } else {
            System.out.println("The list is empty after removing even numbers.");
        }

        // Calculate the average of the remaining numbers
        if (!numbers.isEmpty()) {
            float sum = 0;
            for (int num : numbers) {
                sum += num;
            }
            float average = sum / numbers.size();
            System.out.println("Average of remaining numbers: " + average);
        } else {
            System.out.println("Cannot calculate average, the list is empty.");
        }
    }
}
