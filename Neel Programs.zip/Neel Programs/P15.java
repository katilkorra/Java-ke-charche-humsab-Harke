
class BankingException extends Exception {
    public BankingException(String message) {
        super(message);
    }
}



class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        if (initialBalance < 0) {
            throw new IllegalArgumentException("Initial balance cannot be negative.");
        }
        this.balance = initialBalance;
    }

    // Method to deposit money
    public void deposit(double amount) throws BankingException {
        if (amount < 0) {
            throw new BankingException("Deposit amount cannot be negative.");
        }
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

    // Method to withdraw money
    public void withdraw(double amount) throws BankingException {
        if (amount < 0) {
            throw new BankingException("Withdrawal amount cannot be negative.");
        }
        if (amount > balance) {
            throw new BankingException("Insufficient funds. Current balance: " + balance);
        }
        balance -= amount;
        System.out.println("Withdrew: " + amount);
    }

    
    public double checkBalance() {
        return balance;
    }
}


public class P15 {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(1000); 

        try {
            account.deposit(500); 
            System.out.println("Current Balance: " + account.checkBalance());

            account.withdraw(200); 
            System.out.println("Current Balance: " + account.checkBalance());

            account.withdraw(1500); 
        } catch (BankingException e) {
            System.out.println("Banking Exception: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Illegal Argument Exception: " + e.getMessage());
        }

        try {
            account.deposit(-100); // Attempt to deposit a negative amount
        } catch (BankingException e) {
            System.out.println("Banking Exception: " + e.getMessage());
        }
        
        try {
            account.withdraw(-50); // Attempt to withdraw a negative amount
        } catch (BankingException e) {
            System.out.println("Banking Exception: " + e.getMessage());
        }
    }
}
