abstract class Animal{
    abstract void speak();
    abstract void eat(); 
}

class Dog extends Animal{
    @Override
    void speak()
    {
        System.out.println("Dog speaks boooooh");
    }
    @Override
    void eat()
    {
        System.out.println("Dog eat bones");
    }
}

class Cat extends Animal{
    @Override
    void speak()
    {
        System.out.println("Cat speaks meow.");
    }
    @Override
    void eat()
    {
        System.out.println("Cat takes milk");
    }
}



public class P9 {
    public static void main(String[] args) {
        Dog dog = new Dog();
        Cat cat = new Cat();

        dog.eat();
        cat.speak();
    }
    
}
