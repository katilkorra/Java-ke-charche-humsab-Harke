public class P3 {
    public static void F1()
    {
        System.out.println("Hello World");
    }

    public static void main(String args[])
    {
        F1();
    }
    
}
