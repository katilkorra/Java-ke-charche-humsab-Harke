import java.util.Scanner;

class Car {
    private String brand;
    private int wheels;
    private String color;

    public Car() {
        brand = "Unknown";
        wheels = 0;
        color = "Unknown";
    }

    public Car(String cBrand) {
        brand = cBrand;
        wheels = 4;
        color = "Unknown";
    }

    public Car(String cBrand, int cWheels, String cColor) {
        brand = cBrand;
        wheels = cWheels;
        color = cColor;
    }

    public void displayInfo() {
        System.out.printf("Car Brand is: %s\n", brand);
        System.out.printf("Number of wheels: %d\n", wheels);
        System.out.printf("Car Color is: %s\n", color);
    }

    public void displayInfo(boolean show) {
        if (show) {
            displayInfo(); // Call the other displayInfo method
        } else {
            System.out.printf("Car Brand only Show: %s\n", brand);
        }
    }
}

public class P6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the Brand name: ");
        String cBrand = input.nextLine();
        System.out.println("");

        System.out.print("Enter the number of Tyre: ");
        int cTyre = input.nextInt();
        input.nextLine(); // Consume the leftover newline
        System.out.println("");

        System.out.print("Enter the color of car: ");
        String cColor = input.nextLine();
        System.out.println("");

        Car car1 = new Car();
        Car car2 = new Car(cBrand);
        Car car3 = new Car(cBrand, cTyre, cColor);

        car1.displayInfo();
        car2.displayInfo();
        car3.displayInfo();

        car3.displayInfo(true);
        car3.displayInfo(false);
        
        input.close();
    }
}