public class P2{
    public static void main(String[] args)
    {
        String num1 = "20";
        String num2 = "40";

        int A = Integer.parseInt(num1);
        int B = Integer.parseInt(num2);

        int total = A+B;
        System.out.println(total);
    }
}