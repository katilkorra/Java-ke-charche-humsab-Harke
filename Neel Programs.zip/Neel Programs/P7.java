import java.util.Scanner;

class SubA {
    int num1;
    int num2; 
    public SubA(int A,int B)
    {
        num1 = A;
        num2 = B;
    }

    public int sum()
    {
        int sum = num1 + num2 ; 
        return sum;
    }

    public void display()
    {
        System.out.printf("The sum of two numbers is : " + sum() + "\n");
    }
}

class SubB extends SubA{

    int num3;

    public SubB(int A,int B, int C)
    {
        super(A,B);
        this.num3 = C;
    }

    @Override
    public int sum()
    {
        int sumRes = num1 + num2 + num3 ;
        return sumRes;
    }

    public void display()
    {
        System.out.printf("The sum of three numbers is : " + sum());
    }
}

public class P7{
    public static void main(String args[])
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter 1st number : ");
        int a = input.nextInt();

        System.out.println("Enter 2nd number : ");
        int b = input.nextInt();

        System.out.println("Enter 3rd number : ");
        int c = input.nextInt();

        SubA sub1 = new SubA(a,b);
        SubB sub2 = new SubB(a,b,c);

        sub1.display();
        sub2.display();

        input.close();
    }
}