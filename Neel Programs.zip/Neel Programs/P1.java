public class P1 {
    public static void main(String[] args) {
        float num1 = 2.3F;
        float num2 = 3.4F;
        float total = num1 + num2;
        int sum = (int) total;
        System.out.println(sum);

    }
}