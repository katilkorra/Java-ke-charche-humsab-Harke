import java.util.Scanner;

class Temp {

    private int num1;
    private int num2;

    public Temp(int num1, int num2)
    {
        this.num1 = num1;
        this.num2 = num2;
    }

    public Temp()
    {
        this.num1 = 2;
        this.num2 = 4;
    }


    public int sum()
    {
        int sum = num1 +num2;
        return sum;
    }

    public void result()
    {
        System.out.printf("the sum of the numbers is:" + sum() + "\n");
    }

}

public class P5{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the first Value: ");
        int A = input.nextInt();
        System.out.println("Enter the Second Value: ");
        int B = input.nextInt();

        Temp temp1 = new Temp(A,B);
        temp1.result()  ; 

        Temp temp2 = new Temp();
        temp2.result();

        input.close();
    }
}
