import java.util.Scanner;
public class P11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the value :");
        int num = input.nextInt();

        System.out.print("Enter the diviser :");
        int div = input.nextInt();


        try
        {
            int ans = num/div ;
            System.out.printf("Answer is : " + ans);
        }

        catch(ArithmeticException e)
        {
            System.out.println("Enter correct diviser, not zero. ");
        }
        input.close();
    }
}
